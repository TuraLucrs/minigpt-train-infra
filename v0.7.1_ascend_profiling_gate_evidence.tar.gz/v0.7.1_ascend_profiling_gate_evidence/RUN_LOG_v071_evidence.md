# RUN_LOG — v0.7.1 Ascend Profiling Gate 六点验收（真机）

- 日期：2026-09-10；平台：Atlas A3（4 卡 × 2 芯片，16 逻辑 Ascend910），容器内运行
- 模型：/data/models/Qwen3-32B（权重 SHA-256 与 v0.7 验收记录一致）
- CANN：9.2.0-V100R001C12B080
- 互联拓扑：Atlas A3 cards0-3, 2 chips/card, HCCS intra-card + cross-card board interconnect
- 仓库提交：1ce15410ba4c5c216518f9621d40b1babdbe7320（upgrade/v0.7.1-ascend-profiling-gate）
- 驱动：scripts/run_v071_ascend_profiling_gate.sh（冻结 workload 取自仓库跟踪的 v0.7_ascend_evidence.tar.gz）

## CPU 回归

tests/ 下 11 个测试脚本全部通过（含本版新增 tests/test_profiling_gate.py；
本仓库测试为 check_* + main() 脚本式，直接 python 执行；Gloo 组默认跳过属预期）。

## 协议与时间线

每点：1 warmup + 3 measured repeats + engine reset + 1 次有界 profile replay
（复用确定性 admission script，digest 与 measured 一致，标记 measurement_excluded）；
profiler 窗口 skip/warmup/active = short 8/2/4、long_prefill 6/1/4、mixed 14/1/4，
Level-1 + PipeUtilization + record_shapes + system_interconnection，ranks 0-7；
closed_loop 走 --closed-loop-clients 32。

| 点 | workload/mode/layout | profile_summary 完成时刻 |
|---|---|---|
| 1 | short_short / open_loop / 2xtp4 | 20:20:54 |
| 2 | short_short / open_loop / 4xtp2 | 20:23:46 |
| 3 | long_prefill_short_decode / closed_loop / tp8 | 20:26:30 |
| 4 | long_prefill_short_decode / closed_loop / 4xtp2 | 20:29:03 |
| 5 | mixed / open_loop / tp8 | 20:32:48 |
| 6 | mixed / open_loop / 4xtp2 | 20:36:12 |
| — | 门禁合并 profiling_gate.json | 20:37:14 |

## 验收结论

- profiling_gate.json：complete = true；selection_ready = true；incomplete_reasons = []
- evidence_class = complete_v0.7.1_ascend_profiling_gate
- 产物完整性：6 点 × 8 rank × 6 类 profiler 工件齐全
  （profiler_info*.json / operator_details.csv / kernel_details.csv /
  step_trace_time.csv / trace_view.json / communication.json），
  measured 与 profile replay digest 一致性由门禁校验通过。

## triage 信号（profiling_gate.json → signals）

| 信号 | 触发 | 关键观测 |
|---|---|---|
| paged_kv_block_manager | 是 | mean active internal waste ≈ 0.9939；peak capacity waste ≈ 0.9955 |
| decode_communication_path | 是 | short decode phase fraction ≈ 0.854；非重叠通信占比 ≈ 0.358 |
| chunked_prefill_or_prefix_cache | 是 | long prefill phase fraction ≈ 0.617 vs short ≈ 0.153（Δ ≈ 0.463） |
| host_scheduler_path | 是 | profile free fraction ≈ 0.452 |
| speculative_decoding_or_mtp | 否 | requires_model_feasibility_gate = true |

决策策略：signals 只证明瓶颈存在，不按命中数量自动选题；
优先选择能用单一改动、同模型同 workload A/B 证明收益的方向。

## 本包内容与排除说明

包含：门禁判定 + 六点 {layout_manifest / layout_provenance / profile_manifest /
profile_summary / replica-*} 证据层 + SHA256SUMS。
排除：16GB 原始 profiler trace（保留于运行机 runs/v071_profiling_gate_r2/<point>/profiler/）；
source_workload.json 重复副本（其 SHA-256 已记录于各 profile_manifest，
本体在仓库跟踪的 v0.7_ascend_evidence.tar.gz 内，逐字节一致）。

## 完整性

SHA256SUMS 覆盖本包全部文件（不含自身）；tar.gz 与 SHA256SUMS 见仓库根目录。
