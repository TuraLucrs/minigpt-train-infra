# DIAGNOSIS NOTES — 三条 incomplete 理由的定性（随附证据索引）

本检查 complete=false，但三条 incomplete 理由均已逐条定性；性能结论本身成立
（v0.7 TP8 慢态 1.179 req/s 未复现，今日 TP8 稳定 3.74–3.92 ≈ v0.7.1 的 4.005，
当前比值 ≈ 1.34×，无顺序效应）。正式五态分类因下列三条被跳过。

## R1 "八个 session 的模型或权重不一致" —— checker 过严（结构上必然触发）

- model_identity_sha256 的 payload 含 `model.local_parameter_count`：
  tp8 = 4,095,857,664（32.77B/8），4xtp2 = 16,381,400,064（32.77B/2），
  属 TP 分片固有属性，跨布局必然不同。
- 实测：同布局内指纹完全一致（tp8 四个 session 全为 dd622ccb…；
  4xtp2 四个 session 全为 2854383d…）。
- 权重本体无任何问题：17 个分片文件的 per-file sha256 在全部 8 个 session
  逐个相同（各 session replica-*.json → provenance.weights）。
- 建议：同布局内比对，或将 local_parameter_count 移出 identity payload。

## R2 "tp8 跨 session 输出 digest 不一致" —— 真实但良性、结构化

- 每个 session 内 3 次 measured repeat 逐位一致（v0.7 确定性保证全部成立）。
- 跨 session 恰好两种稳定态：session-01/07 → 53102b8d…；session-04/06 → 656d50dd…
  （tp8 位于顺序 1/4/6/7 → A,B,B,A，无单调漂移，非热/缓存效应）。
- 机制：open-loop 微小时序抖动翻转 batch 边界 → 数值路径分叉。
- 性能影响 ≤4%（态 A 3.743/3.849 vs 态 B 3.915/3.911；且 session-01
  启动时 host load1=62.6，与 CPU 回归测试余波混杂）。

## R3 "4xtp2 跨 session 输出 digest 不一致" —— 同机制、更稀疏

- 4 副本中 3 个（00/02/03）digest 在全部 4 个 session 逐位一致；
  仅 replica-01 在 session-03 翻转一次（af2afce1… vs 其余 5b5c7c82…）。
- goodput 无可见影响（session-03 中位数 5.298，为四个 session 中最高）。

## 机器状态（RUN_LOG.md 表格复述）

频率全程 1800MHz、温度 35–36°C、iowait 0、host CPU 4.2–4.6%；
AICore tp8 18–19% vs 4xtp2 29%。排除降频/过热/IO 等待解释。
