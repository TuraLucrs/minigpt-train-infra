# DIAGNOSIS NOTES — v0.7 TP8 历史慢态复现与判因

修正 checker 口径后，本证据包为 `complete=true`。八个 session 均成功，当前稳定结果为
TP8 3.880 req/s、4×TP2 5.174 req/s，后者为前者的 1.334×。冻结 v0.7 中的 4.24×
没有复现。

## 1. 历史慢态的直接证据

旧 v0.7 TP8 的 `npu-smi` sampler 在模型加载前已经观测到：

- 8 个 device 的 HBM Usage 中位数为 39.5%；
- 8 个 device 的 AICore Usage 中位数为 45.5%。

本次四个 TP8 session 在同一阶段全部是 HBM 4%、AICore 0%。旧 TP8 模型加载后 HBM
上升到约 62.5%，模型进程结束后又回落到约 40%，证明约 40% 的基线占用不属于本项目
进程。证据支持旧测量受到同设备并发负载污染；现有证据无法追溯该负载的进程名称或所有者。

旧 TP8 与本次 `session-04-tp8`、`session-06-tp8` 的输出 digest 完全相同，scheduler
steps 也同为 55。旧运行耗时约 26–28 秒，本次约 16–17 秒，因此 batch 形状不能解释
历史慢态。

## 2. 为什么 goodput 差异被放大

旧 TP8 的原始完成吞吐中位数为 2.433 req/s，本次为 3.880 req/s，即本次快 1.595×。
但旧运行变慢后，满足 SLO 的请求数从本次每轮 64 个降为 33、31、15 个，所以 goodput
进一步跌到 1.179 req/s。4.24× 同时包含设备争用造成的执行变慢和 SLO 阈值造成的离散
放大，不能作为 TP8 与 4×TP2 的稳定架构倍率。

## 3. 原三条 incomplete 的处理

### R1 模型或权重不一致

这是 checker bug。旧指纹包含 `model.local_parameter_count`：TP8 为 4,095,857,664，
4×TP2 为 16,381,400,064，它是 TP 分片属性，不是全局模型身份。修正后只比较模型类型、
完整配置、全局参数量以及 17 个权重文件 SHA-256；八个 session 一致。

### R2/R3 跨 session 输出 digest 不一致

这是实际存在但不阻断本次性能复现的数值变体：

- TP8 有两种 digest，涉及 9/64 个请求；分布为 session-01/07 与 session-04/06；
- 4×TP2 仅 replica-01 在 session-03 翻转，涉及 1 个请求；
- 每个 session 内三次 measured replay 均逐位一致；
- 所有请求的终态、停止原因、输入 token 数和输出 token 数跨 session 一致。

open-loop warmup 形成的 step 边界不同，会改变 batch shape；BF16 和并行归约的数值路径
随之变化，少数接近 greedy 决策边界的 token 会翻转。修正后的门禁保留完整 digest 变体作
警告，但以请求终态和计算长度是否一致判断性能工作量是否可比。

## 4. 当前机器状态与结果稳定性

- NPU 频率全程 1800 MHz；
- 温度中位数 35–36°C；
- Host IO wait 与 CPU/IO PSI 为 0；
- TP8 跨 session CV 为 1.80%，4×TP2 为 1.23%；
- 前后半程变化分别为 +1.33% 和 -1.69%，无顺序效应。

结论：旧 v0.7 TP8 慢态来自被污染的设备运行环境，不是稳定的 TP8 实现性能；当前可复现
倍率为 1.334×。该结论解决历史异常，不等同于已经确定 v0.8 的研究方向。
